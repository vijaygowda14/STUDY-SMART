package com.studysmart.servlet;

public @interface WebServlet {

}
